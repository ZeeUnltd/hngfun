<?php include ('header.php'); ?>
<div id="banner-content" class="row clearfix">

    <div class="col-38">

        <div class="section-heading">
            <h1>Become a better Software Developer</h1>
        </div>

       

    </div>

</div><!--End of Row-->
</header>
<div class="center">

    <div class="section-1 margin"  >We are on a mission of developing world class software Engineers</div>
    <div class="body">
        <div class="section-1-body"> Internship is for 500 interns - The Hotels.ng Software Developers Internship Programme To last for 4 months starting from the end of September 2017.
            The internship is targeted at young Nigerians in Akwa Ibom who want to be software developers and contribute to the growth of technology in Nigeria.</div>



	<div class="section-1 margin"> Join Us </div> 
          <div class="section-1-body"> Join the team of our future world class developers.</br>
	   <button class="button">JOIN TEAM</button>
          </div>

            </div>
    </div>
<?php include ('footer.php'); ?>
